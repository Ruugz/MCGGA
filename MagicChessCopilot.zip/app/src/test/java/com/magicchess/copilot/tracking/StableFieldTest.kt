package com.magicchess.copilot.tracking

import com.magicchess.copilot.domain.RecognitionStatus
import org.junit.Assert.assertEquals
import org.junit.Test

class StableFieldTest {

    private fun StableField.valid(v: String, t: Long) =
        observe(v, 0.9f, RecognitionStatus.VALID, t)

    private fun commit34(f: StableField) {
        f.valid("34", 0)
        f.valid("34", 1)
        f.valid("34", 2)
    }

    @Test
    fun commitsOnlyAfterConfirmFrames() {
        val f = StableField(confirmFrames = 3)
        f.valid("34", 0)
        f.valid("34", 1)
        assertEquals(RecognitionStatus.UNKNOWN, f.reading(2).status)
        f.valid("34", 2)
        val r = f.reading(3)
        assertEquals("34", r.value)
        assertEquals(RecognitionStatus.VALID, r.status)
    }

    @Test
    fun ocrGlitchIsIgnored() {
        val f = StableField(confirmFrames = 3)
        commit34(f)
        f.observe("3A", 0.5f, RecognitionStatus.UNCERTAIN, 3)
        f.valid("39", 4)
        f.valid("34", 5)
        assertEquals("34", f.reading(6).value)
    }

    @Test
    fun realChangeIsAccepted() {
        val f = StableField(confirmFrames = 3)
        commit34(f)
        f.valid("32", 3)
        f.valid("32", 4)
        f.valid("32", 5)
        assertEquals("32", f.reading(6).value)
    }

    @Test
    fun staleValueBecomesUncertain() {
        val f = StableField(confirmFrames = 3, staleMs = 5000)
        commit34(f)
        assertEquals(RecognitionStatus.UNCERTAIN, f.reading(6000).status)
    }
}
