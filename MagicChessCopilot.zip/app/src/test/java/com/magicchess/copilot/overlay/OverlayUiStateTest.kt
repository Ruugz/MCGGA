package com.magicchess.copilot.overlay

import org.junit.Assert.assertEquals
import org.junit.Test

class OverlayUiStateTest {
    @Test
    fun defaultStateIsUncertainNotGuessed() {
        val s = OverlayUiState()
        assertEquals("INSUFFICIENT DATA", s.decision)
        assertEquals("UNKNOWN", s.status)
        assertEquals("UNKNOWN", s.confidence)
        assertEquals("UNKNOWN", s.risk)
    }
}
