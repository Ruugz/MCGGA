package com.magicchess.copilot.decision

import com.magicchess.copilot.domain.GameState
import com.magicchess.copilot.domain.Reading
import com.magicchess.copilot.domain.RecognitionStatus
import org.junit.Assert.assertEquals
import org.junit.Test

class DecisionEngineTest {

    private fun r(v: Int?, c: Float = 0.9f, s: RecognitionStatus = RecognitionStatus.VALID) =
        Reading(v, c, s)

    private val engine = DecisionEngine()

    @Test
    fun unknownStateWaitsWithUnknownRisk() {
        val d = engine.decide(GameState.empty())
        assertEquals(Action.WAIT, d.action)
        assertEquals(Risk.UNKNOWN, d.risk)
    }

    @Test
    fun lowConfidenceWaits() {
        val s = GameState.empty().copy(gold = r(34, 0.2f), hp = r(61), level = r(7))
        assertEquals(Action.WAIT, engine.decide(s).action)
    }

    @Test
    fun healthyEconomyKeeps() {
        val s = GameState.empty().copy(gold = r(34), hp = r(61), level = r(7))
        val d = engine.decide(s)
        assertEquals(Action.KEEP, d.action)
        assertEquals(Risk.LOW, d.risk)
    }

    @Test
    fun criticalHpRolls() {
        val s = GameState.empty().copy(gold = r(20), hp = r(25), level = r(5))
        val d = engine.decide(s)
        assertEquals(Action.ROLL, d.action)
        assertEquals(Risk.HIGH, d.risk)
    }
}
