package com.magicchess.copilot.decision

import com.magicchess.copilot.domain.GameState
import kotlin.math.roundToInt

enum class Action { ROLL, BID, WAIT, STOP, KEEP, LEVEL, SELL, POSITION, SKIP, DO_NOTHING }

enum class Risk { LOW, MEDIUM, HIGH, UNKNOWN }

data class Decision(
    val action: Action,
    val confidence: Float,
    val risk: Risk,
    val reasons: List<String>,
    val limit: String? = null,
)

/** Ambang baseline (bisa dikonfigurasi). Engine penuh + "Jalan Tengah" menyusul di Phase B. */
data class DecisionConfig(
    val rollCost: Int = 2,
    val ecoThreshold: Int = 10,
    val criticalHp: Int = 30,
    val safeHp: Int = 60,
    val minConfidence: Float = 0.6f,
)

/** Deterministik, terpisah dari LLM. Data tidak valid -> WAIT, tidak menebak. */
class DecisionEngine(private val cfg: DecisionConfig = DecisionConfig()) {

    fun decide(s: GameState): Decision {
        val core = listOf("Gold" to s.gold, "HP" to s.hp, "Level" to s.level)
        val bad = core.filter { (_, r) -> !r.isValid || r.confidence < cfg.minConfidence }
        val minConf = core.minOf { it.second.confidence }
        val gold = s.gold.value
        val hp = s.hp.value
        val level = s.level.value

        if (bad.isNotEmpty() || gold == null || hp == null || level == null) {
            val reasons = mutableListOf("Data inti belum cukup valid, tidak ada rekomendasi.")
            bad.forEach { (n, r) ->
                reasons.add("$n: ${r.status.name} (${(r.confidence * 100).roundToInt()}%)")
            }
            return Decision(Action.WAIT, minConf, Risk.UNKNOWN, reasons)
        }

        val auction = s.auction
        val auctionValue = auction.value
        if (auction.isValid && auctionValue != null && auctionValue.contains("OPEN", ignoreCase = true)) {
            return Decision(
                Action.WAIT, minConf, Risk.UNKNOWN,
                listOf("Auction terdeteksi, tetapi Auction Analyzer (Phase F) belum aktif. Tidak ada rekomendasi BID.")
            )
        }

        val base = "Gold $gold, HP $hp, Level $level."
        return when {
            hp <= cfg.criticalHp && gold >= cfg.rollCost -> Decision(
                Action.ROLL, minConf, Risk.HIGH,
                listOf(base, "HP kritis (<= ${cfg.criticalHp}), prioritaskan kekuatan board."),
                limit = "Gold yang dipakai: maksimal $gold"
            )
            hp <= cfg.criticalHp -> Decision(
                Action.DO_NOTHING, minConf, Risk.HIGH,
                listOf(base, "HP kritis tetapi gold tidak cukup untuk roll.")
            )
            gold < cfg.rollCost -> Decision(
                Action.DO_NOTHING, minConf, Risk.MEDIUM,
                listOf(base, "Gold kurang dari biaya roll (${cfg.rollCost}).")
            )
            gold >= cfg.ecoThreshold -> Decision(
                Action.KEEP, minConf,
                if (hp >= cfg.safeHp) Risk.LOW else Risk.MEDIUM,
                listOf(base, "Gold di atas ambang ekonomi (${cfg.ecoThreshold}), pertahankan reserve."),
                limit = "Sisakan minimal ${cfg.ecoThreshold} gold"
            )
            else -> Decision(
                Action.WAIT, minConf, Risk.LOW,
                listOf(base, "Belum ada aksi yang jelas lebih baik.")
            )
        }
    }
}
