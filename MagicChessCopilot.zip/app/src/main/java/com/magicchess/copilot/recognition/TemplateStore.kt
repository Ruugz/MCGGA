package com.magicchess.copilot.recognition

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.magicchess.copilot.roi.NormRect
import java.io.File

/** Template visual buatan user, disimpan lokal di filesDir/templates (tidak pernah di-upload). */
class TemplateStore(context: Context) {

    data class Template(val roiId: String, val label: String, val signature: ImageSignature)

    private val dir = File(context.filesDir, "templates").apply { mkdirs() }
    private val cache = HashMap<String, MutableList<Template>>()
    private var loaded = false

    @Synchronized
    private fun ensureLoaded() {
        if (loaded) return
        dir.listFiles()?.forEach { f ->
            val parts = f.name.removeSuffix(".png").split("__")
            if (parts.size >= 2) {
                BitmapFactory.decodeFile(f.path)?.let { bmp ->
                    cache.getOrPut(parts[0]) { mutableListOf() }
                        .add(Template(parts[0], parts[1], ImageSignature.of(bmp, FULL)))
                    bmp.recycle()
                }
            }
        }
        loaded = true
    }

    @Synchronized
    fun templates(roiId: String): List<Template> {
        ensureLoaded()
        return cache[roiId]?.toList() ?: emptyList()
    }

    @Synchronized
    fun save(roiId: String, label: String, cell: Bitmap) {
        ensureLoaded()
        val safe = label.trim().replace(Regex("[^A-Za-z0-9_-]"), "_")
        require(safe.isNotEmpty()) { "Label kosong" }
        val file = File(dir, "${roiId}__${safe}__${System.currentTimeMillis()}.png")
        file.outputStream().use { cell.compress(Bitmap.CompressFormat.PNG, 100, it) }
        cache.getOrPut(roiId) { mutableListOf() }
            .add(Template(roiId, safe, ImageSignature.of(cell, FULL)))
    }

    private companion object {
        val FULL = NormRect(0f, 0f, 1f, 1f)
    }
}
