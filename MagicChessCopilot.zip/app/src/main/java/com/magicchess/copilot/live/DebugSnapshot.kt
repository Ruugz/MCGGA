package com.magicchess.copilot.live

import android.graphics.Bitmap
import com.magicchess.copilot.domain.RecognitionResult
import com.magicchess.copilot.roi.RegionOfInterest

data class RoiDebug(
    val roi: RegionOfInterest,
    val result: RecognitionResult?,
    val analyzed: Boolean,
)

/** Live frame (thumbnail) + ROI + hasil OCR/CV + confidence + waktu proses. */
data class DebugSnapshot(
    val thumb: Bitmap?,
    val rois: List<RoiDebug>,
    val frameMs: Long,
    val frameW: Int,
    val frameH: Int,
) {
    companion object {
        val EMPTY = DebugSnapshot(null, emptyList(), 0L, 0, 0)
    }
}
