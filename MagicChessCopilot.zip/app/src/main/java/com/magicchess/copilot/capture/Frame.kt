package com.magicchess.copilot.capture

import android.graphics.Bitmap

/** Satu frame layar (hanya di memori, tidak pernah disimpan permanen). */
class Frame(val bitmap: Bitmap, val timestampMs: Long) {
    val width: Int get() = bitmap.width
    val height: Int get() = bitmap.height
}
