package com.magicchess.copilot.roi

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.roundToInt

object RoiCropper {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    fun toRect(w: Int, h: Int, n: NormRect): Rect {
        val l = (n.left * w).roundToInt().coerceIn(0, w - 1)
        val t = (n.top * h).roundToInt().coerceIn(0, h - 1)
        val r = (n.right * w).roundToInt().coerceIn(l + 1, w)
        val b = (n.bottom * h).roundToInt().coerceIn(t + 1, h)
        return Rect(l, t, r, b)
    }

    fun crop(bmp: Bitmap, n: NormRect): Bitmap {
        val rc = toRect(bmp.width, bmp.height, n)
        return Bitmap.createBitmap(bmp, rc.left, rc.top, rc.width(), rc.height())
    }

    /** Downscale ROI ke size x size piksel tanpa membuat crop besar. */
    fun scaledPixels(bmp: Bitmap, n: NormRect, size: Int): IntArray {
        val rc = toRect(bmp.width, bmp.height, n)
        val dst = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(dst).drawBitmap(bmp, rc, Rect(0, 0, size, size), paint)
        val px = IntArray(size * size)
        dst.getPixels(px, 0, size, 0, 0, size, size)
        dst.recycle()
        return px
    }

    fun lumaOf(p: Int): Int = (Color.red(p) * 3 + Color.green(p) * 6 + Color.blue(p)) / 10
}
