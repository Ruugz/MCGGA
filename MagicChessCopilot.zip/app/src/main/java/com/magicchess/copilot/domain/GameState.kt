package com.magicchess.copilot.domain

data class Reading<T>(
    val value: T?,
    val confidence: Float,
    val status: RecognitionStatus,
) {
    val isValid: Boolean get() = status == RecognitionStatus.VALID && value != null

    companion object {
        fun <T> unknown(): Reading<T> = Reading(null, 0f, RecognitionStatus.UNKNOWN)
    }
}

/** GameState aktual, hanya dibangun dari hasil recognition (tidak ada data hardcoded/random). */
data class GameState(
    val gold: Reading<Int>,
    val hp: Reading<Int>,
    val level: Reading<Int>,
    val xp: Reading<String>,
    val round: Reading<String>,
    val shop: Reading<List<String>>,
    val board: Reading<List<String>>,
    val bench: Reading<List<String>>,
    val synergy: Reading<List<String>>,
    val auction: Reading<String>,
    val items: Reading<List<String>>,
    val timestampMs: Long,
) {
    companion object {
        fun empty(now: Long = 0L) = GameState(
            Reading.unknown(), Reading.unknown(), Reading.unknown(), Reading.unknown(),
            Reading.unknown(), Reading.unknown(), Reading.unknown(), Reading.unknown(),
            Reading.unknown(), Reading.unknown(), Reading.unknown(), now
        )
    }
}
