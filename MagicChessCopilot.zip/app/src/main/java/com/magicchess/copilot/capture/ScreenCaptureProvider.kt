package com.magicchess.copilot.capture

import android.content.Intent
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

enum class CaptureState { STOPPED, RUNNING, PAUSED }

interface ScreenCaptureProvider {
    val frames: SharedFlow<Frame>
    val state: StateFlow<CaptureState>
    fun start(resultCode: Int, data: Intent)
    fun pause()
    fun resume()
    fun stop()
    fun onConfigurationChanged()
}
