package com.magicchess.copilot.tracking

import com.magicchess.copilot.domain.Reading
import com.magicchess.copilot.domain.RecognitionStatus

/**
 * Debounce/smoothing: nilai baru baru dianggap perubahan nyata setelah terbaca
 * VALID dan sama sebanyak confirmFrames kali berturut-turut.
 * Glitch OCR seperti 34 -> 3A -> 39 -> 34 tidak mengubah state.
 */
class StableField(
    private val confirmFrames: Int = 3,
    private val staleMs: Long = 5000L,
) {
    private var committed: String? = null
    private var committedConf = 0f
    private var lastValidAt = 0L
    private var pending: String? = null
    private var pendingCount = 0
    private var lastStatus = RecognitionStatus.UNKNOWN

    /** True jika masih perlu frame tambahan untuk memastikan nilai. */
    val needsConfirmation: Boolean get() = committed == null || pending != null

    fun observe(value: String?, confidence: Float, status: RecognitionStatus, nowMs: Long) {
        lastStatus = status
        if (status != RecognitionStatus.VALID || value == null) {
            pending = null
            pendingCount = 0
            return
        }
        if (value == committed) {
            committedConf = 0.7f * committedConf + 0.3f * confidence
            lastValidAt = nowMs
            pending = null
            pendingCount = 0
            return
        }
        if (value == pending) pendingCount++ else {
            pending = value
            pendingCount = 1
        }
        if (pendingCount >= confirmFrames) {
            committed = value
            committedConf = confidence
            lastValidAt = nowMs
            pending = null
            pendingCount = 0
        }
    }

    fun reading(nowMs: Long): Reading<String> {
        val c = committed
        if (c == null) {
            val st = if (lastStatus == RecognitionStatus.INSUFFICIENT_DATA)
                RecognitionStatus.INSUFFICIENT_DATA else RecognitionStatus.UNKNOWN
            return Reading(null, 0f, st)
        }
        if (nowMs - lastValidAt > staleMs) {
            return Reading(c, committedConf * 0.5f, RecognitionStatus.UNCERTAIN)
        }
        return Reading(c, committedConf, RecognitionStatus.VALID)
    }
}
