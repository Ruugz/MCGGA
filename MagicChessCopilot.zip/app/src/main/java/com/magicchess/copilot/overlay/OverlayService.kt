package com.magicchess.copilot.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.magicchess.copilot.capture.CaptureState
import com.magicchess.copilot.capture.MediaProjectionCaptureProvider
import com.magicchess.copilot.live.LiveEngine
import com.magicchess.copilot.live.LiveEngineHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Foreground service (mediaProjection): menjalankan capture, engine, dan overlay. */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var container: DragFrameLayout? = null
    private var debugView: RoiDebugView? = null
    private var debugJob: Job? = null
    private var engine: LiveEngine? = null
    private val owner = OverlayLifecycleOwner()
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val i = intent ?: return START_NOT_STICKY
        when (i.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                // Wajib dipanggil setelah user memberi izin screen capture
                ServiceCompat.startForeground(
                    this, NOTIF_ID, buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
                if (engine != null) return START_NOT_STICKY
                if (!Settings.canDrawOverlays(this)) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                val resultCode = i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = IntentCompat.getParcelableExtra(i, EXTRA_DATA, Intent::class.java)
                if (resultCode != Activity.RESULT_OK || data == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startLive(resultCode, data)
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startLive(resultCode: Int, data: Intent) {
        val e = LiveEngine(this, MediaProjectionCaptureProvider(this))
        try {
            e.start(resultCode, data)
        } catch (ex: Exception) {
            Log.e(TAG, "Gagal memulai capture", ex)
            e.release()
            stopSelf()
            return
        }
        engine = e
        LiveEngineHolder.engine = e
        showOverlay(e)

        uiScope.launch {
            e.captureState.collect { if (it == CaptureState.STOPPED) stopSelf() }
        }
        uiScope.launch {
            e.debugEnabled.collect { on -> if (on) showDebugView(e) else hideDebugView() }
        }
    }

    private fun showOverlay(e: LiveEngine) {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 120
        }

        owner.create()
        val zone = (56 * resources.displayMetrics.density).toInt()
        val view = DragFrameLayout(this, zone) { dx, dy ->
            lp.x += dx.toInt()
            lp.y += dy.toInt()
            container?.let { windowManager.updateViewLayout(it, lp) }
        }
        view.setViewTreeLifecycleOwner(owner)
        view.setViewTreeViewModelStoreOwner(owner)
        view.setViewTreeSavedStateRegistryOwner(owner)

        val compose = ComposeView(this).apply {
            setContent { MaterialTheme { OverlayRoot(engine = e) } }
        }
        view.addView(compose)
        container = view
        windowManager.addView(view, lp)
        owner.resume()
    }

    private fun showDebugView(e: LiveEngine) {
        if (debugView != null) return
        val v = RoiDebugView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(v, lp)
        debugView = v
        debugJob = uiScope.launch { e.debug.collect { v.update(it) } }
    }

    private fun hideDebugView() {
        debugJob?.cancel()
        debugJob = null
        debugView?.let { runCatching { windowManager.removeView(it) } }
        debugView = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        engine?.onConfigurationChanged()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Co-Pilot Live Analysis", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop",
            stopIntent
        ).build()
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Magic Chess Co-Pilot aktif")
            .setContentText("Membaca layar secara lokal (hanya rekomendasi, tanpa otomatisasi)")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        uiScope.cancel()
        hideDebugView()
        container?.let { runCatching { windowManager.removeView(it) } }
        container = null
        engine?.release()
        engine = null
        LiveEngineHolder.engine = null
        owner.destroy()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.magicchess.copilot.action.START"
        const val ACTION_STOP = "com.magicchess.copilot.action.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val TAG = "OverlayService"
        private const val CHANNEL_ID = "copilot_overlay"
        private const val NOTIF_ID = 1001
    }
}

private class OverlayLifecycleOwner : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val controller = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = registry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry

    fun create() {
        controller.performAttach()
        controller.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}
