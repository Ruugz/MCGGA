package com.magicchess.copilot.live

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import com.magicchess.copilot.capture.CaptureState
import com.magicchess.copilot.capture.Frame
import com.magicchess.copilot.capture.ScreenCaptureProvider
import com.magicchess.copilot.decision.DecisionEngine
import com.magicchess.copilot.domain.GameState
import com.magicchess.copilot.domain.RecognitionResult
import com.magicchess.copilot.overlay.OverlayUiState
import com.magicchess.copilot.recognition.CompositeRecognitionEngine
import com.magicchess.copilot.recognition.OcrRecognitionEngine
import com.magicchess.copilot.recognition.RecognitionEngine
import com.magicchess.copilot.recognition.TemplateRecognitionEngine
import com.magicchess.copilot.recognition.TemplateStore
import com.magicchess.copilot.roi.RegionOfInterest
import com.magicchess.copilot.roi.RoiConfig
import com.magicchess.copilot.roi.RoiCropper
import com.magicchess.copilot.tracking.GameStateBuilder
import com.magicchess.copilot.tracking.StableField
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Pipeline: Frame -> ROI -> OCR/CV -> RecognitionResult -> GameState -> Decision -> UI.
 * Berjalan di Dispatchers.Default (tidak memblokir Main Thread).
 * Hanya ROI yang berubah (atau butuh konfirmasi) yang dianalisis ulang.
 */
class LiveEngine(
    context: Context,
    private val provider: ScreenCaptureProvider,
) {
    val templateStore = TemplateStore(context.applicationContext)
    private val recognizer: RecognitionEngine = CompositeRecognitionEngine(
        OcrRecognitionEngine(), TemplateRecognitionEngine(templateStore)
    )
    private val rois: List<RegionOfInterest> = RoiConfig.defaults()
    private val trackers: Map<String, StableField> = rois.associate { it.id to StableField() }
    private val lastSig = HashMap<String, IntArray>()
    private val lastAnalyzedAt = HashMap<String, Long>()
    private val lastResult = HashMap<String, RecognitionResult>()
    private val decisionEngine = DecisionEngine()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Volatile
    private var lastFrame: Frame? = null

    val debugEnabled = MutableStateFlow(false)
    val recording = MutableStateFlow(false)

    private val _ui = MutableStateFlow(
        OverlayUiState.from(GameState.empty(), decisionEngine.decide(GameState.empty()))
    )
    val ui: StateFlow<OverlayUiState> = _ui

    private val _debug = MutableStateFlow(DebugSnapshot.EMPTY)
    val debug: StateFlow<DebugSnapshot> = _debug

    val captureState: StateFlow<CaptureState> get() = provider.state

    fun start(resultCode: Int, data: Intent) {
        provider.start(resultCode, data)
        job = scope.launch {
            provider.frames.collect { frame ->
                try {
                    process(frame)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e(TAG, "Gagal memproses frame", e)
                }
            }
        }
    }

    fun pause() = provider.pause()
    fun resume() = provider.resume()
    fun onConfigurationChanged() = provider.onConfigurationChanged()

    fun release() {
        job?.cancel()
        provider.stop()
        scope.cancel()
        lastFrame = null
    }

    private suspend fun process(frame: Frame) {
        val t0 = SystemClock.elapsedRealtime()
        val now = frame.timestampMs
        lastFrame = frame
        val debugOn = debugEnabled.value
        val debugRois = ArrayList<RoiDebug>(rois.size)

        for (roi in rois) {
            val px = RoiCropper.scaledPixels(frame.bitmap, roi.rect(), SIG_SIZE)
            val sig = IntArray(px.size) { RoiCropper.lumaOf(px[it]) }
            val prev = lastSig[roi.id]
            val changed = prev == null || meanDiff(prev, sig) > CHANGE_THRESHOLD
            lastSig[roi.id] = sig

            val tracker = trackers.getValue(roi.id)
            val due = changed ||
                tracker.needsConfirmation ||
                now - (lastAnalyzedAt[roi.id] ?: 0L) > REFRESH_MS

            var analyzed = false
            if (due) {
                val result = try {
                    recognizer.analyze(frame, roi)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    RecognitionResult.unknown(roi.id, "error", now, e.message)
                }
                lastResult[roi.id] = result
                lastAnalyzedAt[roi.id] = now
                tracker.observe(result.value, result.confidence, result.status, now)
                analyzed = true
            }
            if (debugOn) debugRois.add(RoiDebug(roi, lastResult[roi.id], analyzed))
        }

        val readings = trackers.mapValues { it.value.reading(now) }
        val state = GameStateBuilder.build(readings, now)
        val decision = decisionEngine.decide(state)
        _ui.value = OverlayUiState.from(state, decision)

        if (debugOn) {
            val tw = THUMB_WIDTH
            val th = (tw * frame.height / frame.width.toFloat()).roundToInt().coerceAtLeast(1)
            val thumb = Bitmap.createScaledBitmap(frame.bitmap, tw, th, true)
            _debug.value = DebugSnapshot(
                thumb, debugRois, SystemClock.elapsedRealtime() - t0, frame.width, frame.height
            )
        }
    }

    /** Simpan template dari frame terakhir (hanya crop satu cell, lokal). */
    fun saveTemplate(roiId: String, cellIndex: Int, label: String): String {
        val roi = rois.firstOrNull { it.id.equals(roiId.trim(), ignoreCase = true) }
            ?: return "ROI '$roiId' tidak dikenal"
        val frame = lastFrame ?: return "Belum ada frame. Jalankan Live Analysis dulu."
        if (cellIndex !in 0 until roi.cellCount) return "Cell harus 0..${roi.cellCount - 1}"
        return try {
            val crop = RoiCropper.crop(frame.bitmap, roi.cell(cellIndex))
            templateStore.save(roi.id, label, crop)
            "Template '${label.trim()}' tersimpan untuk ${roi.id}[$cellIndex]"
        } catch (e: Exception) {
            "Gagal menyimpan: ${e.message}"
        }
    }

    private fun meanDiff(a: IntArray, b: IntArray): Int {
        var s = 0L
        for (i in a.indices) s += abs(a[i] - b[i])
        return (s / a.size).toInt()
    }

    private companion object {
        const val TAG = "LiveEngine"
        const val SIG_SIZE = 16
        const val CHANGE_THRESHOLD = 3
        const val REFRESH_MS = 2000L
        const val THUMB_WIDTH = 320
    }
}
