package com.magicchess.copilot.roi

enum class RoiKind { OCR, TEMPLATE }

enum class RoiParser { INT, FRACTION, STAGE }

object RoiIds {
    const val GOLD = "GOLD"
    const val HP = "HP"
    const val LEVEL = "LEVEL"
    const val XP = "XP"
    const val ROUND = "ROUND"
    const val SHOP = "SHOP"
    const val AUCTION = "AUCTION"
    const val BOARD = "BOARD"
    const val BENCH = "BENCH"
    const val SYNERGY = "SYNERGY"
    const val ITEM = "ITEM"
}

/** Koordinat ternormalisasi 0..1 relatif terhadap lebar/tinggi frame. */
data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

data class RegionOfInterest(
    val id: String,
    val kind: RoiKind,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val cols: Int = 1,
    val rows: Int = 1,
    val parser: RoiParser = RoiParser.INT,
) {
    val cellCount: Int get() = cols * rows

    fun rect() = NormRect(left, top, right, bottom)

    fun cell(index: Int): NormRect {
        val col = index % cols
        val row = index / cols
        val cw = (right - left) / cols
        val ch = (bottom - top) / rows
        return NormRect(left + col * cw, top + row * ch, left + (col + 1) * cw, top + (row + 1) * ch)
    }
}
