package com.magicchess.copilot.live

object LiveEngineHolder {
    @Volatile
    var engine: LiveEngine? = null
}
