package com.magicchess.copilot.overlay

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.magicchess.copilot.capture.CaptureState
import com.magicchess.copilot.live.LiveEngine
import kotlin.math.roundToInt

private val PanelBase = Color(0xFF1E1E2E)
private val Dim = Color(0xFFB0B0C0)

@Composable
fun OverlayRoot(engine: LiveEngine) {
    val ui by engine.ui.collectAsState()
    val capture by engine.captureState.collectAsState()
    val debugOn by engine.debugEnabled.collectAsState()
    val rec by engine.recording.collectAsState()

    var expanded by remember { mutableStateOf(false) }
    var showWhy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }
    var opacity by remember { mutableFloatStateOf(0.85f) }

    if (!expanded) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(PanelBase.copy(alpha = opacity))
                .clickable { expanded = true },
            contentAlignment = Alignment.Center
        ) {
            Text("🧠", fontSize = 26.sp)
        }
        return
    }

    Column(
        modifier = Modifier
            .width(280.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(PanelBase.copy(alpha = opacity))
    ) {
        // Header (area drag, tinggi 48dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🧠 MAGIC ANALYZER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(
                text = when (capture) {
                    CaptureState.RUNNING -> "⏸ LIVE"
                    CaptureState.PAUSED -> "▶ PAUSED"
                    CaptureState.STOPPED -> "■ STOPPED"
                },
                color = Color(0xFF7BE0A4),
                fontSize = 12.sp,
                modifier = Modifier.clickable {
                    when (capture) {
                        CaptureState.RUNNING -> engine.pause()
                        CaptureState.PAUSED -> engine.resume()
                        CaptureState.STOPPED -> Unit
                    }
                }
            )
        }

        Column(
            modifier = Modifier
                .heightIn(max = 300.dp)
                .verticalScroll(rememberScrollState())
                .padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ui.fields.forEach { f ->
                val extra = if (f.mark != "✓" && f.confPct > 0) " (${f.confPct}%)" else ""
                Text("${f.label} ${f.text} ${f.mark}$extra", color = Color.White, fontSize = 13.sp)
            }

            Text("DECISION", color = Dim, fontSize = 10.sp)
            Text(ui.decision, color = Color(0xFFFFD166), fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("CONFIDENCE ${ui.confidencePct}%   RISK ${ui.risk}", color = Color.White, fontSize = 12.sp)
            ui.limit?.let { Text("LIMIT: $it", color = Dim, fontSize = 11.sp) }

            if (showWhy) {
                ui.reasons.forEach { Text("• $it", color = Dim, fontSize = 11.sp) }
            }
            note?.let { Text(it, color = Dim, fontSize = 11.sp) }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                PanelButton("WHY?", Modifier.weight(1f)) { showWhy = !showWhy }
                PanelButton("CHAT", Modifier.weight(1f)) {
                    note = "Live Chat tersedia di Phase J."
                }
                PanelButton(if (rec) "● REC" else "RECORD", Modifier.weight(1f)) {
                    engine.recording.value = !engine.recording.value
                    note = if (engine.recording.value) {
                        "REC aktif. Penyimpanan timeline menyusul di Phase C."
                    } else null
                }
                PanelButton("HIDE", Modifier.weight(1f)) { expanded = false }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("DEBUG (kotak ROI)", color = Dim, fontSize = 11.sp)
                Switch(checked = debugOn, onCheckedChange = { engine.debugEnabled.value = it })
            }
            if (debugOn) DebugPanel(engine)

            Text("Transparansi", color = Dim, fontSize = 10.sp)
            Slider(value = opacity, onValueChange = { opacity = it }, valueRange = 0.3f..1f)
        }
    }
}

@Composable
private fun DebugPanel(engine: LiveEngine) {
    val dbg by engine.debug.collectAsState()
    dbg.thumb?.let {
        Image(bitmap = it.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth())
    }
    Text("Frame ${dbg.frameW}x${dbg.frameH} • ${dbg.frameMs} ms", color = Dim, fontSize = 10.sp)
    dbg.rois.forEach { rd ->
        val res = rd.result
        val v = res?.value ?: res?.status?.name ?: "-"
        val pct = ((res?.confidence ?: 0f) * 100).roundToInt()
        val star = if (rd.analyzed) " *" else ""
        Text(
            "${rd.roi.id}: $v  $pct%  ${res?.source ?: "-"}  ${res?.processingMs ?: 0}ms$star",
            color = Color.White,
            fontSize = 10.sp
        )
    }
    Text("* = dianalisis ulang di frame ini", color = Dim, fontSize = 9.sp)
}

@Composable
private fun PanelButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(text, fontSize = 10.sp, color = Color.White, maxLines = 1)
    }
}
