package com.magicchess.copilot.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PanelBase = Color(0xFF1E1E2E)

@Composable
fun OverlayRoot(state: OverlayUiState) {
    var expanded by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }
    var opacity by remember { mutableFloatStateOf(0.85f) }

    if (!expanded) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(PanelBase.copy(alpha = opacity))
                .clickable { expanded = true },
            contentAlignment = Alignment.Center
        ) {
            Text("🧠", fontSize = 26.sp)
        }
    } else {
        Column(
            modifier = Modifier
                .width(250.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(PanelBase.copy(alpha = opacity))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("🧠 Co-Pilot", color = Color.White, fontWeight = FontWeight.Bold)
            InfoRow("Status", state.status)
            InfoRow("Target", state.target)
            Text(
                "Decision: ${state.decision}",
                color = Color(0xFFFFD166),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            InfoRow("Confidence", state.confidence)
            InfoRow("Risk", state.risk)

            note?.let { Text(it, color = Color(0xFFB0B0C0), fontSize = 11.sp) }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                PanelButton("WHY?", Modifier.weight(1f)) {
                    note = "Belum ada data. Decision Engine tersedia di Phase B."
                }
                PanelButton("CHAT", Modifier.weight(1f)) {
                    note = "Live Chat tersedia di Phase J."
                }
                PanelButton("RECORD", Modifier.weight(1f)) {
                    note = "Record & Timeline tersedia di Phase C."
                }
                PanelButton("HIDE", Modifier.weight(1f)) {
                    expanded = false
                }
            }

            Text("Transparansi", color = Color(0xFFB0B0C0), fontSize = 10.sp)
            Slider(
                value = opacity,
                onValueChange = { opacity = it },
                valueRange = 0.3f..1f
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color(0xFFB0B0C0), fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun PanelButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(text, fontSize = 10.sp, color = Color.White, maxLines = 1)
    }
}
