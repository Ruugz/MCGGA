package com.magicchess.copilot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.magicchess.copilot.overlay.OverlayService

class MainActivity : ComponentActivity() {

    private var canDraw by mutableStateOf(false)

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                HomeScreen(
                    canDraw = canDraw,
                    onGrant = {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                    },
                    onStart = { startOverlay() },
                    onStop = {
                        startService(
                            Intent(this, OverlayService::class.java)
                                .setAction(OverlayService.ACTION_STOP)
                        )
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        canDraw = Settings.canDrawOverlays(this)
    }

    private fun startOverlay() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }
}

@Composable
private fun HomeScreen(
    canDraw: Boolean,
    onGrant: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🧠 Magic Chess Co-Pilot", style = MaterialTheme.typography.headlineSmall)
        Text("Phase A: Floating Bubble + Overlay UI")
        Text(
            "Aplikasi ini hanya menampilkan rekomendasi. Tidak ada auto-play, " +
                "auto-click, atau modifikasi game. Semua data tetap lokal."
        )
        Text(if (canDraw) "Izin overlay: AKTIF" else "Izin overlay: BELUM DIBERIKAN")
        if (!canDraw) {
            Button(onClick = onGrant, modifier = Modifier.fillMaxWidth()) {
                Text("Beri izin overlay")
            }
        } else {
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                Text("Mulai overlay")
            }
            OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth()) {
                Text("Stop overlay")
            }
        }
    }
}
