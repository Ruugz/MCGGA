package com.magicchess.copilot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.magicchess.copilot.live.LiveEngineHolder
import com.magicchess.copilot.overlay.OverlayService
import com.magicchess.copilot.roi.RoiConfig

class MainActivity : ComponentActivity() {

    private var canDraw by mutableStateOf(false)

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .setAction(OverlayService.ACTION_START)
                    .putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                HomeScreen(
                    canDraw = canDraw,
                    roiIds = RoiConfig.defaults().joinToString { it.id },
                    onGrant = {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                    },
                    onStart = { requestCapture() },
                    onStop = {
                        startService(
                            Intent(this, OverlayService::class.java)
                                .setAction(OverlayService.ACTION_STOP)
                        )
                    },
                    onSaveTemplate = { roi, cell, label ->
                        LiveEngineHolder.engine?.saveTemplate(roi, cell, label)
                            ?: "Live Analysis belum berjalan."
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        canDraw = Settings.canDrawOverlays(this)
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}

@Composable
private fun HomeScreen(
    canDraw: Boolean,
    roiIds: String,
    onGrant: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSaveTemplate: (String, Int, String) -> String,
) {
    var tplRoi by remember { mutableStateOf("AUCTION") }
    var tplCell by remember { mutableStateOf("0") }
    var tplLabel by remember { mutableStateOf("") }
    var tplMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🧠 Magic Chess Co-Pilot", style = MaterialTheme.typography.headlineSmall)
        Text("Phase E: Live Screen Analysis (MediaProjection → ROI → OCR/CV → GameState → Decision → Overlay)")
        Text(
            "Hanya membaca layar dan memberi rekomendasi. Tidak ada auto-play, auto-click, " +
                "auto-bid, atau modifikasi game. Frame tidak disimpan dan tidak di-upload."
        )
        Text(if (canDraw) "Izin overlay: AKTIF" else "Izin overlay: BELUM DIBERIKAN")
        if (!canDraw) {
            Button(onClick = onGrant, modifier = Modifier.fillMaxWidth()) {
                Text("Beri izin overlay")
            }
        } else {
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                Text("Mulai Live Analysis")
            }
            OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth()) {
                Text("Stop")
            }
        }

        Text("Template visual (opsional)", style = MaterialTheme.typography.titleMedium)
        Text(
            "Saat game tampil di layar, jalankan Live Analysis, lalu buka app ini dan simpan " +
                "template dari frame terakhir. Beri label seperti EMPTY, AUCTION_OPEN, atau nama hero."
        )
        Text("ROI: $roiIds")
        OutlinedTextField(
            value = tplRoi, onValueChange = { tplRoi = it },
            label = { Text("ROI id") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = tplCell, onValueChange = { tplCell = it.filter { c -> c.isDigit() } },
            label = { Text("Nomor cell (mulai 0)") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = tplLabel, onValueChange = { tplLabel = it },
            label = { Text("Label") }, modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { tplMsg = onSaveTemplate(tplRoi, tplCell.toIntOrNull() ?: 0, tplLabel) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Simpan template dari frame terakhir")
        }
        if (tplMsg.isNotEmpty()) Text(tplMsg)
    }
}
