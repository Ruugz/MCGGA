package com.magicchess.copilot.overlay

import android.content.Context
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/**
 * Container overlay yang bisa digeser. Klik tetap diteruskan ke Compose;
 * drag baru diambil alih setelah melewati touch slop (pakai rawX/rawY
 * supaya tidak jitter saat window berpindah).
 */
class DragFrameLayout(
    context: Context,
    private val onDrag: (dx: Float, dy: Float) -> Unit,
) : FrameLayout(context) {

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                lastX = downX
                lastY = downY
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(ev.rawX - downX, ev.rawY - downY) > slop) {
                    dragging = true
                    lastX = ev.rawX
                    lastY = ev.rawY
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (dragging) {
                onDrag(ev.rawX - lastX, ev.rawY - lastY)
                lastX = ev.rawX
                lastY = ev.rawY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}
