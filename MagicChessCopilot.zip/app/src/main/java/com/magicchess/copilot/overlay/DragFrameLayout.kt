package com.magicchess.copilot.overlay

import android.content.Context
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/**
 * Container overlay yang bisa digeser dari area header (dragZonePx teratas).
 * Area di bawahnya tetap bisa di-scroll/di-klik oleh Compose.
 */
class DragFrameLayout(
    context: Context,
    private val dragZonePx: Int,
    private val onDrag: (dx: Float, dy: Float) -> Unit,
) : FrameLayout(context) {

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var canDrag = false
    private var dragging = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                lastX = downX
                lastY = downY
                canDrag = ev.y <= dragZonePx
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (canDrag && !dragging && hypot(ev.rawX - downX, ev.rawY - downY) > slop) {
                    dragging = true
                    lastX = ev.rawX
                    lastY = ev.rawY
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (dragging) {
                onDrag(ev.rawX - lastX, ev.rawY - lastY)
                lastX = ev.rawX
                lastY = ev.rawY
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}
