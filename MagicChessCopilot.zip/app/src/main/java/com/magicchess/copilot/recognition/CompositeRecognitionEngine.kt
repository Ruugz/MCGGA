package com.magicchess.copilot.recognition

import com.magicchess.copilot.capture.Frame
import com.magicchess.copilot.domain.RecognitionResult
import com.magicchess.copilot.roi.RegionOfInterest
import com.magicchess.copilot.roi.RoiKind

/** OCR untuk teks/angka, template/image recognition untuk elemen visual. */
class CompositeRecognitionEngine(
    private val ocr: RecognitionEngine,
    private val template: RecognitionEngine,
) : RecognitionEngine {
    override suspend fun analyze(frame: Frame, roi: RegionOfInterest): RecognitionResult =
        when (roi.kind) {
            RoiKind.OCR -> ocr.analyze(frame, roi)
            RoiKind.TEMPLATE -> template.analyze(frame, roi)
        }
}
