package com.magicchess.copilot.roi

/**
 * ROI default (normalized). NILAI INI MASIH PLACEHOLDER dan HARUS dikalibrasi
 * dengan layar Magic Chess asli lewat Debug Mode (kotak ROI di atas game).
 */
object RoiConfig {
    fun defaults(): List<RegionOfInterest> = listOf(
        RegionOfInterest(RoiIds.GOLD, RoiKind.OCR, 0.47f, 0.90f, 0.53f, 0.98f, parser = RoiParser.INT),
        RegionOfInterest(RoiIds.HP, RoiKind.OCR, 0.02f, 0.05f, 0.10f, 0.12f, parser = RoiParser.INT),
        RegionOfInterest(RoiIds.LEVEL, RoiKind.OCR, 0.02f, 0.88f, 0.10f, 0.97f, parser = RoiParser.INT),
        RegionOfInterest(RoiIds.XP, RoiKind.OCR, 0.10f, 0.88f, 0.20f, 0.97f, parser = RoiParser.FRACTION),
        RegionOfInterest(RoiIds.ROUND, RoiKind.OCR, 0.45f, 0.01f, 0.55f, 0.07f, parser = RoiParser.STAGE),
        RegionOfInterest(RoiIds.SHOP, RoiKind.TEMPLATE, 0.20f, 0.82f, 0.80f, 0.99f, cols = 5),
        RegionOfInterest(RoiIds.AUCTION, RoiKind.TEMPLATE, 0.25f, 0.20f, 0.75f, 0.75f),
        RegionOfInterest(RoiIds.BOARD, RoiKind.TEMPLATE, 0.20f, 0.25f, 0.80f, 0.70f, cols = 8, rows = 4),
        RegionOfInterest(RoiIds.BENCH, RoiKind.TEMPLATE, 0.15f, 0.72f, 0.85f, 0.82f, cols = 9),
        RegionOfInterest(RoiIds.SYNERGY, RoiKind.TEMPLATE, 0.00f, 0.20f, 0.10f, 0.75f, rows = 6),
        RegionOfInterest(RoiIds.ITEM, RoiKind.TEMPLATE, 0.88f, 0.20f, 1.00f, 0.75f, rows = 3),
    )
}
