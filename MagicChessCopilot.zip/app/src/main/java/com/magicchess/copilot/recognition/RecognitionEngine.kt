package com.magicchess.copilot.recognition

import com.magicchess.copilot.capture.Frame
import com.magicchess.copilot.domain.RecognitionResult
import com.magicchess.copilot.roi.RegionOfInterest

interface RecognitionEngine {
    suspend fun analyze(frame: Frame, roi: RegionOfInterest): RecognitionResult
}
