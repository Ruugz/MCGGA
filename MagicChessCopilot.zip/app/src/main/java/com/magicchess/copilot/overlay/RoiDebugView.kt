package com.magicchess.copilot.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import com.magicchess.copilot.domain.RecognitionStatus
import com.magicchess.copilot.live.DebugSnapshot
import kotlin.math.roundToInt

/** Kotak ROI + hasil recognition digambar di atas layar game (tidak bisa disentuh). */
class RoiDebugView(context: Context) : View(context) {

    private var snap: DebugSnapshot = DebugSnapshot.EMPTY
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val grid = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
        color = 0x66FFFFFF
    }
    private val bg = Paint().apply { color = 0xAA000000.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 24f
        color = Color.WHITE
    }

    fun update(s: DebugSnapshot) {
        snap = s
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (rd in snap.rois) {
            val r = rd.roi
            val l = r.left * w
            val t = r.top * h
            val rr = r.right * w
            val b = r.bottom * h
            val res = rd.result
            box.color = when (res?.status) {
                RecognitionStatus.VALID -> Color.GREEN
                RecognitionStatus.UNCERTAIN -> Color.YELLOW
                RecognitionStatus.UNKNOWN -> Color.RED
                RecognitionStatus.INSUFFICIENT_DATA -> Color.GRAY
                null -> Color.CYAN
            }
            canvas.drawRect(l, t, rr, b, box)
            for (i in 1 until r.cols) {
                val x = l + (rr - l) * i / r.cols
                canvas.drawLine(x, t, x, b, grid)
            }
            for (i in 1 until r.rows) {
                val y = t + (b - t) * i / r.rows
                canvas.drawLine(l, y, rr, y, grid)
            }
            val v = res?.value ?: res?.status?.name ?: "-"
            val label = "${r.id} $v ${((res?.confidence ?: 0f) * 100).roundToInt()}% ${res?.processingMs ?: 0}ms"
            val shown = if (label.length > 40) label.take(40) + "…" else label
            canvas.drawRect(l, t, l + txt.measureText(shown) + 8f, t + 30f, bg)
            canvas.drawText(shown, l + 4f, t + 24f, txt)
        }
    }
}
