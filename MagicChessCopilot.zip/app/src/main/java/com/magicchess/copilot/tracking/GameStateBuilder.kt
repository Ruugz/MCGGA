package com.magicchess.copilot.tracking

import com.magicchess.copilot.domain.GameState
import com.magicchess.copilot.domain.Reading
import com.magicchess.copilot.domain.RecognitionStatus
import com.magicchess.copilot.roi.RoiIds

/** Membangun GameState hanya dari hasil recognition yang sudah distabilkan. */
object GameStateBuilder {

    fun build(fields: Map<String, Reading<String>>, now: Long): GameState {
        fun r(id: String): Reading<String> = fields[id] ?: Reading.unknown()
        return GameState(
            gold = r(RoiIds.GOLD).asInt(0..999),
            hp = r(RoiIds.HP).asInt(0..200),
            level = r(RoiIds.LEVEL).asInt(1..15),
            xp = r(RoiIds.XP),
            round = r(RoiIds.ROUND),
            shop = r(RoiIds.SHOP).asList(),
            board = r(RoiIds.BOARD).asList(),
            bench = r(RoiIds.BENCH).asList(),
            synergy = r(RoiIds.SYNERGY).asList(),
            auction = r(RoiIds.AUCTION),
            items = r(RoiIds.ITEM).asList(),
            timestampMs = now
        )
    }

    private fun Reading<String>.asInt(range: IntRange): Reading<Int> {
        val v = value ?: return Reading(null, confidence, status)
        val n = v.toIntOrNull()
        return if (n == null || n !in range) Reading(null, confidence, RecognitionStatus.UNCERTAIN)
        else Reading(n, confidence, status)
    }

    private fun Reading<String>.asList(): Reading<List<String>> =
        Reading(value?.split(",")?.map { it.trim() }, confidence, status)
}
