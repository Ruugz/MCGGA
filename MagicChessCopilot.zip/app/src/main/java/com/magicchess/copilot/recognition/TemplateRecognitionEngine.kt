package com.magicchess.copilot.recognition

import android.os.SystemClock
import com.magicchess.copilot.capture.Frame
import com.magicchess.copilot.domain.RecognitionResult
import com.magicchess.copilot.domain.RecognitionStatus
import com.magicchess.copilot.roi.RegionOfInterest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Image recognition berbasis template user (cocok untuk elemen visual: panel auction,
 * slot kosong, ikon). Tanpa template -> INSUFFICIENT_DATA (tidak menebak).
 * Batasan: average-hash cocok untuk elemen UI, kurang kuat untuk ikon hero yang mirip.
 */
class TemplateRecognitionEngine(private val store: TemplateStore) : RecognitionEngine {

    override suspend fun analyze(frame: Frame, roi: RegionOfInterest): RecognitionResult =
        withContext(Dispatchers.Default) {
            val t0 = SystemClock.elapsedRealtime()
            val now = frame.timestampMs
            val templates = store.templates(roi.id)
            if (templates.isEmpty()) {
                return@withContext RecognitionResult.insufficient(
                    roi.id, SOURCE, now, "belum ada template untuk ${roi.id}",
                    SystemClock.elapsedRealtime() - t0
                )
            }
            val labels = ArrayList<String>(roi.cellCount)
            val confs = ArrayList<Float>(roi.cellCount)
            var valid = 0
            var uncertain = 0
            for (i in 0 until roi.cellCount) {
                val sig = ImageSignature.of(frame.bitmap, roi.cell(i))
                var bestLabel: String? = null
                var bestDist = 1f
                for (t in templates) {
                    val d = t.signature.distanceTo(sig)
                    if (d < bestDist) {
                        bestDist = d
                        bestLabel = t.label
                    }
                }
                val conf = 1f - bestDist
                confs.add(conf)
                when {
                    bestLabel != null && conf >= VALID_CONF -> {
                        labels.add(bestLabel)
                        valid++
                    }
                    bestLabel != null && conf >= UNCERTAIN_CONF -> {
                        labels.add(bestLabel)
                        uncertain++
                    }
                    else -> labels.add("?")
                }
            }
            val status = when {
                valid == roi.cellCount -> RecognitionStatus.VALID
                valid + uncertain > 0 -> RecognitionStatus.UNCERTAIN
                else -> RecognitionStatus.UNKNOWN
            }
            RecognitionResult(
                roiId = roi.id,
                value = if (status == RecognitionStatus.UNKNOWN) null else labels.joinToString(","),
                confidence = confs.average().toFloat(),
                timestampMs = now,
                source = SOURCE,
                status = status,
                processingMs = SystemClock.elapsedRealtime() - t0,
                raw = labels.joinToString(",")
            )
        }

    private companion object {
        const val SOURCE = "template"
        const val VALID_CONF = 0.88f
        const val UNCERTAIN_CONF = 0.70f
    }
}
