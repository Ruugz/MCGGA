package com.magicchess.copilot.recognition

import android.graphics.Bitmap
import android.os.SystemClock
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.magicchess.copilot.capture.Frame
import com.magicchess.copilot.domain.RecognitionResult
import com.magicchess.copilot.domain.RecognitionStatus
import com.magicchess.copilot.roi.RegionOfInterest
import com.magicchess.copilot.roi.RoiCropper
import com.magicchess.copilot.roi.RoiParser
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/** OCR lokal (ML Kit, model ter-bundle) untuk angka/teks. Parsing ketat: tidak menebak "3A" -> 34. */
class OcrRecognitionEngine : RecognitionEngine {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override suspend fun analyze(frame: Frame, roi: RegionOfInterest): RecognitionResult {
        val t0 = SystemClock.elapsedRealtime()
        val now = frame.timestampMs
        val prepared = prepare(RoiCropper.crop(frame.bitmap, roi.rect()))
        val text = recognizer.process(InputImage.fromBitmap(prepared, 0)).await()

        val raw = text.text.trim()
        val ms = SystemClock.elapsedRealtime() - t0
        if (raw.isEmpty()) {
            return RecognitionResult(roi.id, null, 0f, now, SOURCE, RecognitionStatus.UNKNOWN, ms, "")
        }
        val lines = text.textBlocks.flatMap { it.lines }
        val conf = if (lines.isEmpty()) 0f else lines.map { it.confidence }.average().toFloat()
        val parsed = parse(raw, roi.parser)
        val status = when {
            parsed == null -> RecognitionStatus.UNCERTAIN
            conf >= VALID_CONF -> RecognitionStatus.VALID
            conf >= UNCERTAIN_CONF -> RecognitionStatus.UNCERTAIN
            else -> RecognitionStatus.UNKNOWN
        }
        return RecognitionResult(roi.id, parsed, conf, now, SOURCE, status, ms, raw)
    }

    private fun prepare(crop: Bitmap): Bitmap {
        if (crop.height >= MIN_HEIGHT) return crop
        val f = (MIN_HEIGHT + crop.height - 1) / crop.height
        return Bitmap.createScaledBitmap(crop, crop.width * f, crop.height * f, true)
    }

    private fun parse(raw: String, parser: RoiParser): String? {
        val t = raw.replace(Regex("\\s"), "")
        val re = when (parser) {
            RoiParser.INT -> Regex("^\\d{1,4}$")
            RoiParser.FRACTION -> Regex("^\\d{1,3}/\\d{1,3}$")
            RoiParser.STAGE -> Regex("^\\d{1,2}[-:]\\d{1,2}$")
        }
        return if (re.matches(t)) t else null
    }

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { cont.resume(it) }
        addOnFailureListener { cont.resumeWithException(it) }
    }

    private companion object {
        const val SOURCE = "ocr"
        const val MIN_HEIGHT = 64
        const val VALID_CONF = 0.80f
        const val UNCERTAIN_CONF = 0.50f
    }
}
