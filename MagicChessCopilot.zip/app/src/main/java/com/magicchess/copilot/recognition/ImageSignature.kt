package com.magicchess.copilot.recognition

import android.graphics.Bitmap
import android.graphics.Color
import com.magicchess.copilot.roi.NormRect
import com.magicchess.copilot.roi.RoiCropper
import kotlin.math.abs

/** Tanda tangan visual ringan: average-hash 8x8 + warna rata-rata. */
data class ImageSignature(val hash: Long, val r: Int, val g: Int, val b: Int) {

    /** 0 = identik, 1 = sangat berbeda. */
    fun distanceTo(o: ImageSignature): Float {
        val h = java.lang.Long.bitCount(hash xor o.hash) / 64f
        val c = (abs(r - o.r) + abs(g - o.g) + abs(b - o.b)) / (3f * 255f)
        return (0.6f * h + 0.4f * c).coerceIn(0f, 1f)
    }

    companion object {
        fun of(bmp: Bitmap, n: NormRect): ImageSignature {
            val px = RoiCropper.scaledPixels(bmp, n, 8)
            val luma = IntArray(px.size) { RoiCropper.lumaOf(px[it]) }
            val mean = luma.average()
            var hash = 0L
            for (i in luma.indices) {
                if (luma[i] >= mean) hash = hash or (1L shl i)
            }
            val r = px.sumOf { Color.red(it) } / px.size
            val g = px.sumOf { Color.green(it) } / px.size
            val b = px.sumOf { Color.blue(it) } / px.size
            return ImageSignature(hash, r, g, b)
        }
    }
}
