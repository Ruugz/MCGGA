package com.magicchess.copilot.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Capture layar lewat MediaProjection + VirtualDisplay + ImageReader.
 * - Frame dibatasi (minIntervalMs) dan di-drop (DROP_OLDEST) kalau analyzer lambat.
 * - Ukuran/rotasi dinamis lewat onConfigurationChanged().
 * - Semua resource dilepas di stop().
 * Tidak ada root, memory reading, injection, atau modifikasi game.
 */
class MediaProjectionCaptureProvider(
    private val context: Context,
    private val minIntervalMs: Long = 250L,
) : ScreenCaptureProvider {

    private val _frames = MutableSharedFlow<Frame>(
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    override val frames: SharedFlow<Frame> = _frames.asSharedFlow()

    private val _state = MutableStateFlow(CaptureState.STOPPED)
    override val state: StateFlow<CaptureState> = _state.asStateFlow()

    private val lock = Any()
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var width = 0
    private var height = 0
    private var dpi = 0
    private var lastEmitAt = 0L

    @Volatile
    private var paused = false

    override fun start(resultCode: Int, data: Intent) {
        synchronized(lock) {
            check(projection == null) { "Capture sudah berjalan" }
            val t = HandlerThread("copilot-capture").also { it.start() }
            thread = t
            val h = Handler(t.looper)
            handler = h

            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(resultCode, data)
            projection = p
            // Android 14+: callback wajib didaftarkan sebelum createVirtualDisplay
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stop()
                }
            }, h)

            val (w, hh, d) = sizeNow()
            width = w
            height = hh
            dpi = d
            val r = newReader()
            reader = r
            display = p.createVirtualDisplay(
                "MagicCopilotCapture", width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, h
            )
            paused = false
            _state.value = CaptureState.RUNNING
        }
    }

    override fun pause() {
        if (_state.value == CaptureState.RUNNING) {
            paused = true
            _state.value = CaptureState.PAUSED
        }
    }

    override fun resume() {
        if (_state.value == CaptureState.PAUSED) {
            paused = false
            _state.value = CaptureState.RUNNING
        }
    }

    override fun stop() {
        synchronized(lock) {
            val p = projection
            if (p == null) {
                _state.value = CaptureState.STOPPED
                return
            }
            projection = null // putus rekursi dari callback onStop
            runCatching { display?.release() }
            display = null
            runCatching {
                reader?.setOnImageAvailableListener(null, null)
                reader?.close()
            }
            reader = null
            runCatching { p.stop() }
            thread?.quitSafely()
            thread = null
            handler = null
            paused = false
            _state.value = CaptureState.STOPPED
        }
    }

    override fun onConfigurationChanged() {
        handler?.post { resizeIfNeeded() }
    }

    private fun resizeIfNeeded() {
        synchronized(lock) {
            val d = display ?: return
            val (w, h, dp) = sizeNow()
            if (w == width && h == height) return
            width = w
            height = h
            dpi = dp
            val old = reader
            val fresh = newReader()
            reader = fresh
            d.resize(w, h, dp)
            d.surface = fresh.surface
            old?.setOnImageAvailableListener(null, null)
            old?.close()
        }
    }

    private fun newReader(): ImageReader =
        ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).also { r ->
            r.setOnImageAvailableListener({ onImage(it) }, handler)
        }

    private fun onImage(r: ImageReader) {
        val image = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (paused || now - lastEmitAt < minIntervalMs) return
            lastEmitAt = now
            val bmp = image.toBitmap()
            _frames.tryEmit(Frame(bmp, now))
        } catch (e: Exception) {
            Log.e(TAG, "Gagal membaca frame", e)
        } finally {
            image.close()
        }
    }

    private fun Image.toBitmap(): Bitmap {
        val plane = planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * width
        val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    @Suppress("DEPRECATION")
    private fun sizeNow(): Triple<Int, Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dpiNow = context.resources.displayMetrics.densityDpi
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.maximumWindowMetrics.bounds
            Triple(b.width(), b.height(), dpiNow)
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Triple(dm.widthPixels, dm.heightPixels, dpiNow)
        }
    }

    private companion object {
        const val TAG = "CaptureProvider"
    }
}
