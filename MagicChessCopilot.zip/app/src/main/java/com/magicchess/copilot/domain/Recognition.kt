package com.magicchess.copilot.domain

enum class RecognitionStatus { VALID, UNCERTAIN, UNKNOWN, INSUFFICIENT_DATA }

/** Hasil recognition satu ROI. Tidak pernah berisi tebakan: kalau ragu -> status bukan VALID. */
data class RecognitionResult(
    val roiId: String,
    val value: String?,
    val confidence: Float,
    val timestampMs: Long,
    val source: String,
    val status: RecognitionStatus,
    val processingMs: Long = 0L,
    val raw: String? = null,
) {
    companion object {
        fun unknown(roiId: String, source: String, now: Long, raw: String? = null, ms: Long = 0L) =
            RecognitionResult(roiId, null, 0f, now, source, RecognitionStatus.UNKNOWN, ms, raw)

        fun insufficient(roiId: String, source: String, now: Long, raw: String? = null, ms: Long = 0L) =
            RecognitionResult(roiId, null, 0f, now, source, RecognitionStatus.INSUFFICIENT_DATA, ms, raw)
    }
}
