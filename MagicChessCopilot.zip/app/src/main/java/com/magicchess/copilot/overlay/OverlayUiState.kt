package com.magicchess.copilot.overlay

import com.magicchess.copilot.decision.Decision
import com.magicchess.copilot.domain.GameState
import com.magicchess.copilot.domain.Reading
import com.magicchess.copilot.domain.RecognitionStatus
import kotlin.math.roundToInt

data class FieldLine(val label: String, val text: String, val mark: String, val confPct: Int)

/** State overlay, selalu diturunkan dari GameState + Decision (tidak ada data demo). */
data class OverlayUiState(
    val fields: List<FieldLine>,
    val decision: String,
    val confidencePct: Int,
    val risk: String,
    val reasons: List<String>,
    val limit: String?,
) {
    companion object {
        fun from(s: GameState, d: Decision): OverlayUiState = OverlayUiState(
            fields = listOf(
                line("GOLD", s.gold),
                line("HP", s.hp),
                line("LEVEL", s.level),
                line("XP", s.xp),
                line("ROUND", s.round),
                line("AUCTION", s.auction),
            ),
            decision = d.action.name,
            confidencePct = (d.confidence * 100).roundToInt(),
            risk = d.risk.name,
            reasons = d.reasons,
            limit = d.limit
        )

        private fun <T> line(label: String, r: Reading<T>): FieldLine {
            val text = r.value?.toString() ?: r.status.name.replace('_', ' ')
            val mark = when (r.status) {
                RecognitionStatus.VALID -> "✓"
                RecognitionStatus.UNCERTAIN -> "~"
                RecognitionStatus.UNKNOWN -> "?"
                RecognitionStatus.INSUFFICIENT_DATA -> "∅"
            }
            return FieldLine(label, text, mark, (r.confidence * 100).roundToInt())
        }
    }
}
