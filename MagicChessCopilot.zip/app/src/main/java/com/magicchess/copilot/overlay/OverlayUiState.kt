package com.magicchess.copilot.overlay

/**
 * State yang ditampilkan di overlay.
 * Uncertainty-First: default semua UNKNOWN, tidak boleh menebak.
 * Akan diisi Decision Engine mulai Phase B.
 */
data class OverlayUiState(
    val status: String = "UNKNOWN",
    val target: String = "UNKNOWN",
    val decision: String = "INSUFFICIENT DATA",
    val confidence: String = "UNKNOWN",
    val risk: String = "UNKNOWN",
)
