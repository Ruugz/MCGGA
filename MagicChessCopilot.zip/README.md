# Magic Chess Co-Pilot (Phase A)

Aplikasi pendamping: OBSERVE → ANALYZE → PREDICT → RECOMMEND → RECORD → REVIEW.
Tidak ada auto-play / auto-click / modifikasi game. Data lokal saja.

## Phase A: Floating Bubble + Overlay UI
- Bubble 🧠 bisa digeser, tap untuk expand, HIDE untuk collapse
- Panel: status, target, decision, confidence, risk + tombol WHY? / CHAT / RECORD / HIDE
- Slider transparansi
- Semua nilai default UNKNOWN / INSUFFICIENT DATA (Uncertainty-First)

## Build
Push ke GitHub, buka tab Actions, jalankan workflow "Android CI",
lalu unduh artifact `magic-chess-copilot-debug-apk`.

## Next
Phase B: Manual GameState + Decision Engine
