# Magic Chess Co-Pilot (Phase E: Live Screen Analysis)

Pipeline: Game Screen → MediaProjection → Frame → ROI → OCR/CV → RecognitionResult
→ GameState → Decision Engine → Overlay.

Tidak ada auto-play / auto-click / auto-bid / memory reading / modifikasi game.
Frame hanya di memori, tidak disimpan permanen, tidak di-upload. Semua offline.

## Build
Push ke GitHub → Actions → "Android CI" → unduh artifact APK.

## Kalibrasi (WAJIB sebelum Phase E bisa PASS)
ROI di `roi/RoiConfig.kt` masih placeholder. Di HP: jalankan Live Analysis, buka game,
aktifkan DEBUG di overlay, lalu sesuaikan koordinat ROI sampai kotak pas.

## Template visual
Elemen visual (shop, board, auction, dst.) dikenali lewat template yang kamu simpan
dari app (label mis. EMPTY, AUCTION_OPEN, nama hero). Tanpa template: INSUFFICIENT_DATA.
