# Magic Analyzer

Standalone Android project for the Magic Chess / Magic Auction analyzer.

Current MVP:
- Live Analyzer toggle
- Magic Chess Analyzer toggle
- Magic Auction Analyzer toggle
- Player Behavior toggle
- AI Chat toggle
- Record toggle
- Auto Analysis toggle
- Mock GameState
- Deterministic mock recommendation
- Overlay permission entry
- Analyze Now

Build:
`gradle assembleDebug`

GitHub Actions:
`.github/workflows/build.yml`

The current recognition/capture/AI modules are intentionally not claimed as production-ready.
