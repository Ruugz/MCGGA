package com.magicanalyzer;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    TextView title(String s) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextColor(Color.WHITE); v.setTextSize(20);
        v.setPadding(24,20,24,20); return v;
    }

    Button toggle(String label) {
        Button b = new Button(this);
        b.setText(label + "  [OFF]");
        b.setOnClickListener(v -> {
            boolean on = !b.getText().toString().endsWith("[ON]");
            b.setText(label + (on ? "  [ON]" : "  [OFF]"));
            status.setText(on ? "Active: " + label : "Stopped: " + label);
        });
        return b;
    }

    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18);
        root.setBackgroundColor(Color.rgb(16,16,20));

        root.addView(title("🧠 MAGIC ANALYZER"));
        status = title("Status: Ready");
        root.addView(status);

        Button live = toggle("🧠 LIVE ANALYZER");
        root.addView(live);

        root.addView(toggle("♟ MAGIC CHESS ANALYZER"));
        root.addView(toggle("🔨 MAGIC AUCTION ANALYZER"));
        root.addView(toggle("🧠 PLAYER BEHAVIOR"));
        root.addView(toggle("💬 AI CHAT"));
        root.addView(toggle("● RECORD"));
        root.addView(toggle("🔄 AUTO ANALYSIS"));

        TextView state = title("MOCK GAME STATE\nRound 8   Gold 37   HP 64   Level 6\nHero A: ★★ 8/9\n\nRECOMMENDATION\n🟢 ROLL — LIMIT 20 GOLD\nConfidence: 86%  Risk: MEDIUM");
        root.addView(state);

        Button overlay = new Button(this);
        overlay.setText("FLOATING OVERLAY PERMISSION");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else status.setText("Overlay permission already granted.");
        });
        root.addView(overlay);

        Button analyze = new Button(this);
        analyze.setText("ANALYZE NOW");
        analyze.setOnClickListener(v -> status.setText("Manual analysis completed using mock GameState."));
        root.addView(analyze);

        scroll.addView(root);
        setContentView(scroll);
    }
}
