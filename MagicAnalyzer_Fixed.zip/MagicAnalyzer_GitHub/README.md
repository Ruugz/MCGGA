# Magic Analyzer

Standalone Android project for the Magic Chess / Magic Auction analyzer.

## Current MVP
- Live Analyzer toggle
- Magic Chess Analyzer toggle
- Magic Auction Analyzer toggle
- Player Behavior toggle
- AI Chat toggle
- Record toggle
- Auto Analysis toggle
- Mock GameState
- Deterministic mock recommendation
- Overlay permission entry
- Analyze Now

## Build locally

```bash
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Workflow: `.github/workflows/build.yml`

- Triggers on push / PR to main|master and manual dispatch
- Builds debug APK
- Uploads artifact named `magic-analyzer-debug`

The current recognition/capture/AI modules are intentionally not claimed as production-ready.
