# Magic Analyzer

Standalone Android project for Magic Chess / Magic Auction analyzer.

## Features (MVP)
- Live Analyzer toggle
- Magic Chess Analyzer toggle
- Magic Auction Analyzer toggle
- Player Behavior toggle
- AI Chat toggle
- Record toggle
- Auto Analysis toggle
- Mock GameState
- Deterministic mock recommendation
- Overlay permission entry
- Analyze Now

## Build locally
```bash
./gradlew assembleDebug
```

## GitHub Actions
Workflow: `.github/workflows/build.yml`  
Builds debug APK and uploads as artifact.
